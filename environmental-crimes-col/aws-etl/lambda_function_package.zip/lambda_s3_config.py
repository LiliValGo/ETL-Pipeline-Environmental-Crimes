import boto3

def get_s3_client_and_bucket():
    """
    Configura el cliente de S3 y retorna el bucket
    :return: Cliente S3 y nombre del bucket
    """
    # Establece el cliente S3
    s3 = boto3.client('s3')
    bucket_name = 'data-environmental'
    
    return {"s3": s3, "bucket_name": bucket_name}
