import json
import boto3
from datetime import datetime
from lambda_s3_config import get_s3_client_and_bucket
from lambda_s3_keys import get_file_keys
from lambda_s3_download import download_files_from_s3

s3_client = boto3.client('s3')

# Función para serializar objetos datetime en JSON
def custom_serializer(obj):
    if isinstance(obj, datetime):
        return obj.isoformat()
    raise TypeError(f"Type {type(obj)} not serializable")

def lambda_handler(event, context):
    """
    Función Lambda principal que orquesta la obtención de archivos desde S3 y 
    también incluye la marca de tiempo actual en la respuesta.
    """

    # Paso 1: Obtener cliente S3 y nombre del bucket
    s3_data = get_s3_client_and_bucket()
    s3 = s3_data['s3']
    bucket_name = s3_data['bucket_name']
    
    # Paso 2: Obtener las claves de los archivos desde S3
    keys = get_file_keys()

    # Verificación de que `keys` es un diccionario
    if not isinstance(keys, dict):
        raise TypeError(f"Se esperaba un diccionario para `keys`, pero se recibió {type(keys)}")
    
    # Verificar que `keys` contiene la clave necesaria 'crimes_key'
    if 'crimes_key' not in keys:
        raise KeyError("La clave 'crimes_key' no está presente en `keys`")

    # Paso 3: Descargar los archivos de S3 y leer su contenido
    response = download_files_from_s3(s3, bucket_name, keys)
    
    # Leer el contenido del archivo (como texto o bytes)
    file_content = response['crimes_response']['Body'].read().decode('utf-8')
    
    # Paso 4: Guardar el contenido procesado en S3
    processed_file_key = f"processed/{keys['crimes_key']}_processed_{datetime.now().isoformat()}.txt"
    s3_client.put_object(
        Bucket=bucket_name,
        Key=processed_file_key,
        Body=file_content
    )
    
    # Paso 5: Obtener la hora actual
    now = datetime.now()
    current_time = now.isoformat()

    # Paso 6: Devolver solo el enlace al archivo procesado
    s3_file_url = f"https://{bucket_name}.s3.amazonaws.com/{processed_file_key}"
    
    # Respuesta con la hora y el enlace al archivo procesado
    combined_response = {
        "current_time": current_time,
        "s3_file_url": s3_file_url
    }

    # Serializar la respuesta con el serializador personalizado para datetime
    return {
        'statusCode': 200,
        'body': json.dumps(combined_response, default=custom_serializer)
    }
