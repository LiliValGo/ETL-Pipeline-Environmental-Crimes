import boto3

def download_files_from_s3(s3, bucket_name, keys):
    """
    Descarga archivos de S3 utilizando las claves provistas
    :param s3: Cliente de S3
    :param bucket_name: Nombre del bucket en S3
    :param keys: Diccionario con las claves de los archivos a descargar
    :return: Respuestas con los archivos descargados
    """
    crimes_response = s3.get_object(Bucket=bucket_name, Key=keys['crimes_key'])
    return {
        "crimes_response": crimes_response
    } 
 
