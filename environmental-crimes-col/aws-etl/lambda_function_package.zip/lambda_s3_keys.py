def get_file_keys():
    crimes_environmental_col = 'environmental/environmental_crime.json'
    return {"crimes_key": crimes_environmental_col
           }
